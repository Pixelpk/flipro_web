<?php

namespace App\Http\Livewire;

use App\Models\Project;
use App\Models\ProjectAccess;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class LiveProjectDetailComponent extends Component
{
    public Project $project;
    public $team;
    public $user;
    public $roles;
    public $userRoles = [];
    public $selectedUser;

    public function render()
    {
        return view('livewire.live-project-detail-component');
    }

    public function addUser($type)
    {
        $oldRecord = $this->team->where('user_id', $this->selectedUser)->first();

        $roles = [];

        foreach($this->roles as $role){
            $roles[$role] = false;
            if(in_array($role, $this->userRoles)){
                $roles[$role] = true;
            }
        }

        if($oldRecord){
            $oldRecord->roles = $roles;
            $oldRecord->update();
        }else {
            ProjectAccess::forceCreate([
                'project_id' => $this->project->id,
                'acting_as' => $type,
                'roles' => $roles,
                'user_id' => $this->selectedUser
            ]);
        }
        $this->getTeam();
        $this->reset(['userRoles']);
    }

    public function getTeam()
    {
        $this->team = ProjectAccess::where('project_id', $this->project->id)->get();
    }

    public function deleteUser($item)
    {
        ProjectAccess::find($item['id'])->delete();
        $this->getTeam();
    }

    public function mount(Request $request, Project $project)
    {
        $this->roles = config('roles.projectRoles');
        $this->user = Auth::user();
        $this->getTeam();
        $this->project = $project;    
    }

    public function getFranchisesProperty()
    {
        return $this->team->where('acting_as', 'franchise');
    }

    public function getHomeOwnersProperty()
    {
        return $this->team->where('acting_as', 'home-owner');
    }

    public function getBuildersProperty()
    {
        return $this->team->where('acting_as', 'builder');
    }

    public function getEvaluatorsProperty()
    {
        return $this->team->where('acting_as', 'evaluator');
    }
}
