<?php

namespace App\Http\Livewire\Tables;

use App\Models\Project;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Mediconesystems\LivewireDatatables\Column;
use Mediconesystems\LivewireDatatables\Http\Livewire\LivewireDatatable;

class ProjectTable extends LivewireDatatable
{
    protected $listeners = ['refreshTable'];
    
    public function builder()
    {
        $user = Auth::user();
        $projects = Project::query();
        if(!$user->hasRole('administrator')){
            return $projects->where('user_id', Auth::id())->orWhere('lead_user_id', Auth::id());
        }

        return $projects;
    }

    public function columns()
    {
        return [
            Column::name('title'),
            Column::name('applicant_name'),
            Column::name('anticipated_budget'),
            Column::name('project_address'),
            Column::name('project_state'),
            Column::name('phone'),
            Column::name('email'),
            Column::name('current_property_value'),
            Column::name('property_debt'),
            Column::callback(['cross_collaterized'], function($value){
                return $value ? 'Yes' : 'No';
            })->label('Cross Collaterized'),
            Column::callback(['user_id'], function($userId){
                return User::find($userId)->name;
            })->label('Franchisee'),
            Column::callback(['lead_user_id'], function($userId){
                return User::find($userId)->name ?? "Not Assigned";
            })->label('Home Owner'),
            Column::name('status'),
            Column::callback(['id'], function($id){
                return "<div style='width:100px'><i class='bx bx-pencil cursor-pointer' wire:click='edit($id)'></i> <a href='/projects/$id'><i class='bx bx-show-alt'></i></a></div>";
            }),
        ];
    }

    public function edit($id)
    {
        $this->emit('editModel', $id);
    }

    public function refreshTable()
    {
        $this->refreshLivewireDatatable();
    }
}