<?php

namespace App\Http\Livewire;

use App\Models\Event;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class LiveEventsComponent extends Component
{
    public $user;
    public $title;
    public $description;
    public $event_date;
    public $model;

    protected $listeners = ['editModel' => 'edit', 'deleteModel' => 'deleteConfirmation'];

    public function mount()
    {
        $this->user = Auth::user();
    }

    public function create()
    {
        $this->validate();
        $user = Event::forceCreate([
            'title' => $this->title,
            'description' => $this->description,
            'event_date' => $this->event_date,
            'user_id' => $this->user->id,
        ]);

        $this->dispatchBrowserEvent('alert', [
            'title' => "Success",
            'text' => 'Task created successfully',
            'type' => "success",
            'confirmButtonClass' => 'btn btn-primary',
            'buttonsStyling' => false,
        ]);

        $this->emit('refreshTable');
        $this->dispatchBrowserEvent('toggleModal', [
            'id' => "userCreateModal",
            'action' => 'hide',
        ]);
        $this->reset([
            'title', 'description', 'event_date', 'model',
        ]);
    }

    protected $rules = [
        'title' => 'required',
        'description' => 'required',
        'event_date' => 'required|date',
    ];

    public function update()
    {
        $this->validate([
            'title' => 'required',
            'description' => 'required',
            'event_date' => 'required|date',
        ]);

        $this->model->title = $this->title;
        $this->model->description = $this->description;
        $this->model->event_date = $this->event_date;

        $this->model->update();

        $this->dispatchBrowserEvent('alert', [
            'title' => "Success",
            'text' => 'Tasks updated successfully',
            'type' => "success",
            'confirmButtonClass' => 'btn btn-primary',
            'buttonsStyling' => false,
        ]);

        $this->emit('refreshTable');
        $this->dispatchBrowserEvent('toggleModal', [
            'id' => "userCreateModal",
            'action' => 'hide',
        ]);
        $this->reset([
            'title', 'description', 'event_date', 'model',
        ]);
    }

    public function openModal()
    {
        $this->reset([
            'title', 'description', 'event_date', 'model',
        ]);
    }

    public function edit(Event $event)
    {
        $this->model = $event;
        $this->title = $event->title;
        $this->description = $event->description;
        $this->event_date = $event->event_date;

        $this->dispatchBrowserEvent('toggleModal', [
            'id' => "userCreateModal",
            'action' => 'show',
        ]);
    }

    public function deleteConfirmation(Event $event)
    {
        $this->model = $event;
        $this->dispatchBrowserEvent('toggleModal', [
            'id' => "userDeleteModal",
            'action' => 'show',
        ]);
    }

    public function delete()
    {
        $this->model->delete();
        $this->emit('refreshTable');
        $this->reset([
            'title', 'description', 'event_date', 'model',
        ]);
        $this->dispatchBrowserEvent('toggleModal', [
            'id' => "userDeleteModal",
            'action' => 'hide',
        ]);
        $this->dispatchBrowserEvent('alert', [
            'title' => "Success",
            'text' => 'Task deleted successfully',
            'type' => "success",
            'confirmButtonClass' => 'btn btn-primary',
            'buttonsStyling' => false,
        ]);
    }

    public function render()
    {
        return view('livewire.live-events-component');
    }
}
