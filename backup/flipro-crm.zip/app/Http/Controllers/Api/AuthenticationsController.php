<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Builder;
use App\Models\Evaluator;
use App\Models\Fcm;
use App\Models\Franchise;
use App\Models\HomeOwner;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthenticationsController extends Controller
{
    public function authenticate(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
            'app' => 'required|in:admin,franchise,tradesmen'
        ]);

        $user = Auth::guard('web')->attempt([
            'email' => $request->email,
            'password' => $request->password
        ]);

        if(!$user) {
            return response([
                'message' => 'Invalid email address or password',
                'data' => []
            ], 401);
        }

        $user = User::where('email', $request->email)->first();
        
        if($request->fcm){
            $fcm = Fcm::firstOrCreate([
                'user_id' => $user->id,
                'token' => $request->fcm,
            ]);
            $fcm->active = true;
            $fcm->update();
        }

        return response([
            'message' => 'Logged in successfully',
            'data' => [
                'user' => $user,
                'token' => $user->createToken('app')->plainTextToken
            ]
        ]);

    }
}
