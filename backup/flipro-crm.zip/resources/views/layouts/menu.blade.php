@php

$user = \Auth::user();

@endphp

<!-- BEGIN: Main Menu-->
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true" style="background-color: #165C98">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="/">
                    <div class="brand-logo"><svg height="40" viewBox="0 0 161.463 48.311" width="161.463" xmlns="http://www.w3.org/2000/svg"><path d="m192.06 507.363h22.566v6.929h-13.4v5.632h11.445v6.512h-11.444v13.177h-9.167z" fill="#fff" transform="translate(-191.457 -500.009)"/><path d="m227.795 507.363h9.128v24.308h10.611v7.941h-19.739z" fill="#fff" transform="translate(-199.71 -500.009)"/><path d="m258.108 507.363h9.148v32.249h-9.148z" fill="#fff" transform="translate(-206.711 -500.009)"/><path d="m321.449 538.9v-32.253h15.213a20.331 20.331 0 0 1 6.468.792 6.972 6.972 0 0 1 3.607 2.936 9.505 9.505 0 0 1 1.37 5.225 9.7 9.7 0 0 1 -.8 4.645c-.7 1.3-1.989 3.437-3.347 3.774a5.673 5.673 0 0 1 3.774 4.045 33.846 33.846 0 0 1 1.125 7.576 6.381 6.381 0 0 0 .484 3.256h-9.153l-.615-7.329a3.675 3.675 0 0 0 -3.144-3.623c-.824-.056-4.175-.137-5.008-.137h-.806v11.093zm9.168-18.181h4.024a13.089 13.089 0 0 0 2.529-.467 2.5 2.5 0 0 0 1.548-1.072 3.384 3.384 0 0 0 .6-1.983 3.31 3.31 0 0 0 -.947-2.542q-.948-.886-3.561-.886h-4.193z" fill="#fff" transform="translate(-221.34 -499.844)"/><path d="m293.624 497.8h-15.712v40.152h12.5v-10.19h3.215a14.981 14.981 0 1 0 0-29.962zm2.83 16.1a3.614 3.614 0 0 1 -3.615 3.607h-2.43v-8.844h2.43a3.614 3.614 0 0 1 3.615 3.607z" fill="#fff" transform="translate(-211.285 -497.801)"/><path d="m375.95 506.647c-8.444 0-15.3 7.221-15.3 16.128s6.852 16.121 15.3 16.121 15.3-7.214 15.3-16.121-6.85-16.128-15.3-16.128zm0 24.786c-3.468 0-6.275-3.875-6.275-8.657s2.807-8.658 6.275-8.658 6.283 3.875 6.283 8.658-2.807 8.657-6.283 8.657z" fill="#fff" transform="translate(-230.394 -499.844)"/><g fill="#61a2d9"><path d="m294 503.524h-9.632v35.751h2.307v-13.487h7.325a11.132 11.132 0 0 0 0-22.264zm0 19.957h-7.325v-17.65h7.325a8.825 8.825 0 1 1 0 17.65z" transform="translate(-212.777 -499.123)"/><path d="m191.276 559.159v-4.531h2.334a3.4 3.4 0 0 1 .992.111 1.06 1.06 0 0 1 .553.413 1.281 1.281 0 0 1 -.393 1.829 1.715 1.715 0 0 1 -.491.178.954.954 0 0 1 .588.405 1.778 1.778 0 0 1 .2.282l.678 1.313h-1.582l-.748-1.385a1.072 1.072 0 0 0 -.254-.349.588.588 0 0 0 -.343-.105h-.124v1.84zm1.407-2.7h.591a2.162 2.162 0 0 0 .371-.062.377.377 0 0 0 .228-.142.422.422 0 0 0 .088-.263.416.416 0 0 0 -.139-.337.839.839 0 0 0 -.522-.118h-.615z" transform="translate(-191.276 -510.925)"/><path d="m198.967 554.628h3.753v.968h-2.35v.72h2.179v.924h-2.179v.895h2.417v1.026h-3.821z" transform="translate(-193.052 -510.925)"/><path d="m206.244 554.628h1.307l1.707 2.507v-2.507h1.32v4.531h-1.32l-1.7-2.489v2.489h-1.317z" transform="translate(-194.733 -510.925)"/><path d="m214.176 556.873a2.146 2.146 0 0 1 2.34-2.346 2.369 2.369 0 0 1 1.743.608 2.289 2.289 0 0 1 .612 1.7 2.79 2.79 0 0 1 -.267 1.3 1.91 1.91 0 0 1 -.773.791 2.553 2.553 0 0 1 -1.26.283 2.892 2.892 0 0 1 -1.268-.244 1.908 1.908 0 0 1 -.814-.773 2.561 2.561 0 0 1 -.313-1.319zm1.4.006a1.52 1.52 0 0 0 .255.986.964.964 0 0 0 1.392.006 1.675 1.675 0 0 0 .248-1.054 1.4 1.4 0 0 0 -.258-.934.882.882 0 0 0 -.7-.3.85.85 0 0 0 -.68.3 1.525 1.525 0 0 0 -.257.996z" transform="translate(-196.565 -510.902)"/><path d="m221.646 554.628h1.464l1.021 3.261 1.007-3.261h1.42l-1.682 4.531h-1.518z" transform="translate(-198.29 -510.925)"/><path d="m232.123 558.411h-1.59l-.221.748h-1.43l1.7-4.531h1.527l1.7 4.531h-1.459zm-.291-.98-.5-1.629-.495 1.629z" transform="translate(-199.961 -510.925)"/><path d="m236.213 554.628h4.256v1.119h-1.428v3.412h-1.4v-3.412h-1.427z" transform="translate(-201.654 -510.925)"/><path d="m243.883 554.628h3.752v.968h-2.349v.72h2.179v.924h-2.179v.895h2.414v1.026h-3.821z" transform="translate(-203.426 -510.925)"/><path d="m255.222 554.628h1.307l1.706 2.507v-2.507h1.32v4.531h-1.32l-1.7-2.489v2.489h-1.317z" transform="translate(-206.045 -510.925)"/><path d="m263.154 556.873a2.145 2.145 0 0 1 2.34-2.346 2.369 2.369 0 0 1 1.743.608 2.289 2.289 0 0 1 .612 1.7 2.789 2.789 0 0 1 -.268 1.3 1.91 1.91 0 0 1 -.773.791 2.551 2.551 0 0 1 -1.259.283 2.893 2.893 0 0 1 -1.269-.244 1.917 1.917 0 0 1 -.814-.773 2.56 2.56 0 0 1 -.312-1.319zm1.4.006a1.52 1.52 0 0 0 .255.986.965.965 0 0 0 1.393.006 1.681 1.681 0 0 0 .247-1.054 1.4 1.4 0 0 0 -.258-.934.882.882 0 0 0 -.7-.3.851.851 0 0 0 -.681.3 1.525 1.525 0 0 0 -.256.996z" transform="translate(-207.876 -510.902)"/><path d="m270.809 554.628h1.33l.478 2.536.7-2.536h1.326l.7 2.533.479-2.533h1.323l-1 4.531h-1.373l-.794-2.853-.791 2.853h-1.374z" transform="translate(-209.644 -510.925)"/><path d="m285.017 554.628h2.328a1.592 1.592 0 0 1 1.139.362 1.356 1.356 0 0 1 .378 1.03 1.4 1.4 0 0 1 -.413 1.072 1.787 1.787 0 0 1 -1.26.386h-.766v1.682h-1.407zm1.407 1.932h.343a.88.88 0 0 0 .568-.141.454.454 0 0 0 .164-.361.5.5 0 0 0 -.141-.361.737.737 0 0 0 -.535-.149h-.4z" transform="translate(-212.926 -510.925)"/><path d="m294.236 558.411h-1.59l-.221.748h-1.425l1.7-4.531h1.527l1.7 4.531h-1.466zm-.291-.98-.5-1.629-.495 1.629z" transform="translate(-214.307 -510.925)"/><path d="m298.011 554.628h1.556l.914 1.528.914-1.528h1.546l-1.762 2.633v1.9h-1.4v-1.9z" transform="translate(-215.927 -510.925)"/><path d="m309.78 554.628h1.33l.478 2.536.7-2.536h1.325l.7 2.533.479-2.533h1.324l-1 4.531h-1.374l-.8-2.853-.791 2.853h-1.373z" transform="translate(-218.645 -510.925)"/><path d="m319.943 554.628h1.4v1.585h1.53v-1.585h1.406v4.531h-1.406v-1.833h-1.53v1.833h-1.4z" transform="translate(-220.992 -510.925)"/><path d="m328.1 554.628h3.752v.968h-2.349v.72h2.179v.924h-2.179v.895h2.416v1.026h-3.819z" transform="translate(-222.877 -510.925)"/><path d="m335.382 554.628h1.307l1.706 2.507v-2.507h1.32v4.531h-1.315l-1.7-2.489v2.489h-1.317z" transform="translate(-224.558 -510.925)"/><path d="m347.009 554.628h1.555l.914 1.528.914-1.528h1.547l-1.762 2.633v1.9h-1.4v-1.9z" transform="translate(-227.243 -510.925)"/><path d="m354.6 556.873a2.144 2.144 0 0 1 2.339-2.346 2.369 2.369 0 0 1 1.743.608 2.288 2.288 0 0 1 .612 1.7 2.8 2.8 0 0 1 -.267 1.3 1.909 1.909 0 0 1 -.773.791 2.553 2.553 0 0 1 -1.26.283 2.891 2.891 0 0 1 -1.268-.244 1.914 1.914 0 0 1 -.815-.773 2.567 2.567 0 0 1 -.311-1.319zm1.4.006a1.516 1.516 0 0 0 .255.986.964.964 0 0 0 1.392.006 1.68 1.68 0 0 0 .248-1.054 1.4 1.4 0 0 0 -.258-.934.882.882 0 0 0 -.7-.3.85.85 0 0 0 -.68.3 1.52 1.52 0 0 0 -.257.996z" transform="translate(-228.996 -510.902)"/><path d="m365.952 554.628h1.4v2.7a2.265 2.265 0 0 1 -.125.758 1.64 1.64 0 0 1 -.392.625 1.571 1.571 0 0 1 -.561.375 2.8 2.8 0 0 1 -.979.151 6.168 6.168 0 0 1 -.722-.046 1.87 1.87 0 0 1 -.654-.184 1.637 1.637 0 0 1 -.481-.39 1.438 1.438 0 0 1 -.3-.522 2.721 2.721 0 0 1 -.13-.766v-2.7h1.4v2.764a.79.79 0 0 0 .205.579.887.887 0 0 0 1.137 0 .788.788 0 0 0 .205-.582z" transform="translate(-230.938 -510.925)"/><path d="m374.919 557.636 1.332-.083a1.015 1.015 0 0 0 .176.494.739.739 0 0 0 .619.276.682.682 0 0 0 .461-.142.4.4 0 0 0 .008-.641 1.794 1.794 0 0 0 -.718-.262 3.045 3.045 0 0 1 -1.314-.55 1.108 1.108 0 0 1 -.395-.875 1.187 1.187 0 0 1 .2-.659 1.337 1.337 0 0 1 .609-.488 2.833 2.833 0 0 1 1.114-.178 2.278 2.278 0 0 1 1.324.323 1.394 1.394 0 0 1 .542 1.027l-1.319.078a.619.619 0 0 0 -.687-.584.56.56 0 0 0 -.368.1.319.319 0 0 0 -.124.252.251.251 0 0 0 .1.195 1.14 1.14 0 0 0 .47.167 5.9 5.9 0 0 1 1.314.4 1.389 1.389 0 0 1 .578.5 1.274 1.274 0 0 1 .182.672 1.436 1.436 0 0 1 -.242.8 1.509 1.509 0 0 1 -.674.558 2.715 2.715 0 0 1 -1.091.19 2.247 2.247 0 0 1 -1.6-.445 1.759 1.759 0 0 1 -.497-1.125z" transform="translate(-233.689 -510.902)"/><path d="m382.494 554.628h3.752v.968h-2.346v.72h2.179v.924h-2.179v.895h2.417v1.026h-3.821z" transform="translate(-235.438 -510.925)"/><path d="m389.759 554.628h1.4v3.415h2.185v1.117h-3.585z" transform="translate(-237.116 -510.925)"/><path d="m396.566 554.628h1.4v3.415h2.185v1.117h-3.585z" transform="translate(-238.688 -510.925)"/></g></svg></div>
                    
                </a></li>
            <li class="nav-item mt-1 mb-1 nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="bx bx-x d-block d-xl-none font-medium-4 primary"></i><i class="toggle-icon bx font-medium-4 d-none d-xl-block primary" data-ticon="bx-disc"></i></a></li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content mt-2">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="">
            <li class=" nav-item mt-1 mb-1"><a href="/"><i class="bx bx-home-alt"></i><span class="menu-title" data-i18n="">Dashboard</span></a>
            </li>
            <li class=" nav-item mt-1 mb-1"><a href="/tasks"><i class="bx bx-calendar"></i><span class="menu-title" data-i18n="">Tasks</span></a>
            </li>
            <li class=" nav-item mt-1 mb-1"><a href="#"><i class="bx bx-user-circle"></i><span class="menu-title" data-i18n="Starter kit">Leads</span></a>
                <ul class="menu-content">
                    @if($user->hasRole("view-leads"))
                    <li class="{{Request::path() == 'leads' ? 'active' : ''}}"><a href="/leads"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="1 column">Leads </span></a>
                    </li>
                    
                    @endif
                    @if($user->hasRole("view-segments"))
                    <li class="{{Request::path() == 'segments' ? 'active' : ''}}"><a href="/segments"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="1 column">Segments </span></a>
                    </li>
                    @endif
                    @if($user->hasRole("view-tags"))
                    <li class="{{Request::path() == 'tags' ? 'active' : ''}}"><a href="/tags"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="1 column">Tags </span></a>
                    </li>
                    @endif
                </ul>
            </li>
            <li class=" nav-item mt-1 mb-1"><a href="#"><i class="bx bx-envelope"></i><span class="menu-title" data-i18n="Starter kit">Emails</span></a>
                <ul class="menu-content">
                    @if($user->hasRole("view-inbox"))
                    <li class="{{Request::path() == 'inbox' ? 'active' : ''}}"><a href="/inbox"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="1 column">Inbox </span></a>
                    </li>
                    @endif
                    @if($user->hasRole("view-campaigns"))
                    <li class="{{Request::path() == 'campaigns' ? 'active' : ''}}"><a href="/campaigns"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="1 column">Campaigns </span></a>
                    </li>
                    @endif
                </ul>
            </li>
            <li class=" nav-item mt-1 mb-1"><a href="#"><i class="bx bx-building"></i><span class="menu-title" data-i18n="Starter kit">Projects</span></a>
                <ul class="menu-content">
                    @if($user->hasRole("view-projects"))
                    <li class="{{Request::path() == 'projects' ? 'active' : ''}}"><a href="/projects"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="1 column">Projects </span></a>
                    </li>
                    @endif
                    @if($user->hasRole("view-contracts"))
                    <li class="{{Request::path() == 'contracts' ? 'active' : ''}}"><a href="/contracts"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="1 column">Contracts </span></a>
                    </li>
                    @endif
                </ul>
            </li>
            <li class=" nav-item mt-1 mb-1"><a href="#"><i class="bx bx-user-circle"></i><span class="menu-title" data-i18n="Starter kit">Users</span></a>
                <ul class="menu-content">
                    @if($user->hasRole("view-admin"))
                    <li class="{{Request::path() == 'users/admin' ? 'active' : ''}}"><a href="/users/admin"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="1 column">Administrators </span></a>
                    </li>
                    @endif
                    @if($user->hasRole("view-franchise"))
                    <li class="{{Request::path() == 'users/franchise' ? 'active' : ''}}"><a href="/users/franchise"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="2 columns">Franchises</span></a>
                    </li>
                    @endif
                    @if($user->hasRole("view-evaluator"))
                    <li class="{{Request::path() == 'users/evaluator' ? 'active' : ''}}"><a href="/users/evaluator"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="Fixed navbar">Evaluators</span></a>
                    </li>
                    @endif
                    @if($user->hasRole('view-home-owner'))
                    <li class="{{Request::path() == 'users/home-owner' ? 'active' : ''}}"><a href="/users/home-owner"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="Fixed layout">Home Owners</span></a>
                    </li>
                    @endif
                    @if($user->hasRole('view-builder'))
                    <li class="{{Request::path() == 'users/builder' ? 'active' : ''}}"><a href="/users/builder"><i class="bx bx-right-arrow-alt"></i><span class="menu-item" data-i18n="Static layout">Builders</span></a>
                    </li>
                    @endif
                </ul>
            </li>
        </ul>
    </div>
</div>
<!-- END: Main Menu-->