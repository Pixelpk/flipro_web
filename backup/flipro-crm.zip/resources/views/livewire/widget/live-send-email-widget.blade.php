<div action="#" id="compose-form" wire:ignore>
    <div class="card-content">
        <div class="card-body pt-0">
            <div class="form-label-group">
                <input type="email" id="emailTo" wire:model='to' class="form-control" placeholder="To" required>
                <label for="emailTo">To</label>
            </div>
            <div class="form-label-group">
                <input type="email" id="emailTo" wire:model='subject' class="form-control" placeholder="Subject" required>
                <label for="emailTo">To</label>
            </div>
            <!-- Compose mail Quill editor -->
            <div class="snow-container border rounded p-50 ">
                <div x-data x-ref="quillEditor" x-init="
                quill = new Quill($refs.quillEditor, {theme: 'snow'});
                quill.on('text-change', function () {
                    @this.set('replyMessage', quill.root.innerHTML)
                });
            "></div>
                <div class="d-flex justify-content-end">
                    <div class="compose-quill-toolbar pb-0">
                        <span class="ql-formats mr-0">
                            <button class="ql-bold"></button>
                            <button class="ql-italic"></button>
                            <button class="ql-underline"></button>
                            <button class="ql-link"></button>
                            <button class="ql-image"></button>
                        </span>
                    </div>
                </div>
            </div>
            <div class="form-group mt-2">
                <div class="custom-file">
                    <input type="file" multiple multiple wire:model='attachments' class="custom-file-input" id="emailAttach">
                    <label class="custom-file-label" for="emailAttach">Attach file</label>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-end pt-0">
        <button type="reset" class="btn btn-light-secondary cancel-btn mr-1">
            <i class='bx bx-x mr-25'></i>
            <span class="d-sm-inline d-none">Cancel</span>
        </button>
        <button wire:loading.attr='disabled' wire:target='attachments'
        wire:click='send'  type="submit" class="btn-send btn btn-primary">
            <i class='bx bx-send mr-25'></i> <span class="d-sm-inline d-none">Send</span>
        </button>
    </div>
</div>