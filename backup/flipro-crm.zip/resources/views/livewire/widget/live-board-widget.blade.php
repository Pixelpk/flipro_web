<div class="col-4 col-md-4">
    <div class="row">
        <div class="col-md-12 col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">New</h4>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div id="accordion">
                            @foreach ($newProjects as $item)
                            <div class="card accordion">
                                <div class="card-header accordion" id="heading{{$item->id}}">
                                    <h5 class="mb-0" data-toggle="collapse" data-target="#collapse{{$item->id}}"
                                        aria-expanded="true" aria-controls="collapse{{$item->id}}">
                                        <button class="btn btn-link w-100 text-left">
                                            {{$item->title}}
                                            <i class="bx bx-caret-down float-right"></i>
                                        </button>
                                    </h5>
                                </div>
        
                                <div id="collapse{{$item->id}}" class="collapse" aria-labelledby="heading{{$item->id}}" data-parent="#accordion">
                                    <div class="card-body" style="padding: 0px;">
                                        <img class="mt-1" style="width:100%;" src="{{$item->cover_photo}}" alt="">
                                        <ul class="mt-1 mb-2">
                                            <li>
                                                <b>Applicant Name:</b> {{$item->applicant_name}}
                                            </li>
                                            <li>
                                                <b>Applicant Email:</b> {{$item->email}}
                                            </li>
                                            <li>
                                                <b>Applicant Phone:</b> {{$item->phone}}
                                            </li>
                                            <li>
                                                <b>Property State:</b> {{$item->project_state}}
                                            </li>
                                            <li>
                                                <b>Property Address:</b> {{$item->project_address}}
                                            </li>
                                            <li>
                                                <b>Cross Collaterized:</b> {{$item->cross_collaterized ? 'Yes' : 'No'}}
                                            </li>
                                            <li>
                                                <b>Current Value:</b> {{$item->current_property_value}}
                                            </li>
                                            <li>
                                                <b>Current Debts:</b> {{$item->property_debt}}
                                            </li>
                                            <li>
                                                <b>Anticipated Budget:</b> {{$item->anticipated_budget}}
                                            </li>
                                        </ul>
                                        <a href="/projects/{{$item->id}}"><button class="btn btn-primary">View</button></a>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        {{$newProjects->links()}}
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-12">
            <div class="card dashboard">
                <div class="card-header">
                    <h4 class="card-title">Closed</h4>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div id="accordion">
                            @foreach ($closedProjects as $item)
                            <div class="card accordion">
                                <div class="card-header accordion" id="heading{{$item->id}}">
                                    <h5 class="mb-0" data-toggle="collapse" data-target="#collapse{{$item->id}}"
                                        aria-expanded="true" aria-controls="collapse{{$item->id}}">
                                        <button class="btn btn-link w-100 text-left">
                                            {{$item->title}}
                                            <i class="bx bx-caret-down float-right"></i>
                                        </button>
                                    </h5>
                                </div>
        
                                <div id="collapse{{$item->id}}" class="collapse" aria-labelledby="heading{{$item->id}}" data-parent="#accordion">
                                    <div class="card-body" style="padding: 0px;">
                                        <img class="mt-1" style="width:100%;" src="{{$item->cover_photo}}" alt="">
                                        <ul class="mt-1 mb-2">
                                            <li>
                                                <b>Applicant Name:</b> {{$item->applicant_name}}
                                            </li>
                                            <li>
                                                <b>Applicant Email:</b> {{$item->email}}
                                            </li>
                                            <li>
                                                <b>Applicant Phone:</b> {{$item->phone}}
                                            </li>
                                            <li>
                                                <b>Property State:</b> {{$item->project_state}}
                                            </li>
                                            <li>
                                                <b>Property Address:</b> {{$item->project_address}}
                                            </li>
                                            <li>
                                                <b>Cross Collaterized:</b> {{$item->cross_collaterized ? 'Yes' : 'No'}}
                                            </li>
                                            <li>
                                                <b>Current Value:</b> {{$item->current_property_value}}
                                            </li>
                                            <li>
                                                <b>Current Debts:</b> {{$item->property_debt}}
                                            </li>
                                            <li>
                                                <b>Anticipated Budget:</b> {{$item->anticipated_budget}}
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        {{$newProjects->links()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-4 col-md-4">
    <div class="row">
        <div class="col-md-12 col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">In-Progress</h4>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div id="accordion">
                            @foreach ($inProgressProjects as $item)
                            <div class="card accordion">
                                <div class="card-header accordion" id="heading{{$item->id}}">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapse{{$item->id}}"
                                            aria-expanded="true" aria-controls="collapse{{$item->id}}">
                                            {{$item->title}}
                                        </button>
                                    </h5>
                                </div>
        
                                <div id="collapse{{$item->id}}" class="collapse" aria-labelledby="heading{{$item->id}}" data-parent="#accordion">
                                    <div class="card-body" style="padding: 0px;">
                                        <img class="mt-1" style="width:100%;" src="{{$item->cover_photo}}" alt="">
                                        <ul class="mt-1 mb-2">
                                            <li>
                                                <b>Applicant Name:</b> {{$item->applicant_name}}
                                            </li>
                                            <li>
                                                <b>Applicant Email:</b> {{$item->email}}
                                            </li>
                                            <li>
                                                <b>Applicant Phone:</b> {{$item->phone}}
                                            </li>
                                            <li>
                                                <b>Property State:</b> {{$item->project_state}}
                                            </li>
                                            <li>
                                                <b>Property Address:</b> {{$item->project_address}}
                                            </li>
                                            <li>
                                                <b>Cross Collaterized:</b> {{$item->cross_collaterized ? 'Yes' : 'No'}}
                                            </li>
                                            <li>
                                                <b>Current Value:</b> {{$item->current_property_value}}
                                            </li>
                                            <li>
                                                <b>Current Debts:</b> {{$item->property_debt}}
                                            </li>
                                            <li>
                                                <b>Anticipated Budget:</b> {{$item->anticipated_budget}}
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        {{$newProjects->links()}}
                    </div>
                </div>
            </div>
        </div>
        {{-- <div class="col-md-12 col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Project Closed</h4>
                </div>
                <div class="card-content">
                    <div class="card-body">
        
                    </div>
                </div>
            </div>
        </div> --}}
    </div>
</div>
<div class="col-md-4 col-4">
    <div class="row">
        <div class="col-md-12 col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Complete</h4>
                </div>
                <div class="card-content">
                    <div class="card-body">
                        <div id="accordion">
                            @foreach ($completedProjects as $item)
                            <div class="card accordion">
                                <div class="card-header accordion" id="heading{{$item->id}}">
                                    <h5 class="mb-0" data-toggle="collapse" data-target="#collapse{{$item->id}}"
                                        aria-expanded="true" aria-controls="collapse{{$item->id}}">
                                        <button class="btn btn-link w-100 text-left">
                                            {{$item->title}}
                                            <i class="bx bx-caret-down float-right"></i>
                                        </button>
                                    </h5>
                                </div>
        
                                <div id="collapse{{$item->id}}" class="collapse" aria-labelledby="heading{{$item->id}}" data-parent="#accordion">
                                    <div class="card-body" style="padding: 0px;">
                                        <img class="mt-1" style="width:100%;" src="{{$item->cover_photo}}" alt="">
                                        <ul class="mt-1 mb-2">
                                            <li>
                                                <b>Applicant Name:</b> {{$item->applicant_name}}
                                            </li>
                                            <li>
                                                <b>Applicant Email:</b> {{$item->email}}
                                            </li>
                                            <li>
                                                <b>Applicant Phone:</b> {{$item->phone}}
                                            </li>
                                            <li>
                                                <b>Property State:</b> {{$item->project_state}}
                                            </li>
                                            <li>
                                                <b>Property Address:</b> {{$item->project_address}}
                                            </li>
                                            <li>
                                                <b>Cross Collaterized:</b> {{$item->cross_collaterized ? 'Yes' : 'No'}}
                                            </li>
                                            <li>
                                                <b>Current Value:</b> {{$item->current_property_value}}
                                            </li>
                                            <li>
                                                <b>Current Debts:</b> {{$item->property_debt}}
                                            </li>
                                            <li>
                                                <b>Anticipated Budget:</b> {{$item->anticipated_budget}}
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        {{$newProjects->links()}}
                    </div>
                </div>
            </div>
        </div>
        {{-- <div class="col-md-12 col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Re-evaluation</h4>
                </div>
                <div class="card-content">
                    <div class="card-body">
                    </div>
                </div>
            </div>
        </div> --}}
    </div>
</div>