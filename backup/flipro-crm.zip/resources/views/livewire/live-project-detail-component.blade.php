<div class="app-content content">
    <div class="content-overlay"></div>
    <button class="btn btn-lg btn-primary rotate" style="
    position: fixed;
    right: -75px;
    top: 50%;
    z-index: 99; border-bottom-right-radius: 0px; border-bottom-left-radius: 0px">
        Progress Timeline</button>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-12 mb-2 mt-1">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h5 class="content-header-title float-left pr-1 mb-0">Home</h5>
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb p-0 mb-0">
                                <li class="breadcrumb-item"><a href="/"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="#">Project Details</a>
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <section id="basic-horizontal-layouts">
                <div class="row match-height">
                    <div class="col-md-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">{{$project->title}}</h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    @php
                                                    $photo = $project->photos[0] ?? '/no-image.png';
                                                    if($photo)
                                                        if(filter_var($photo, FILTER_VALIDATE_URL)){
                                                            $photo = explode("/", $photo);
                                                            $photo = $photo[count($photo) -2] . '/' . $photo[count($photo)-1];
                                                        }   
                                                    @endphp
                                                    <img src="/stream/{{$photo}}" width="100%" alt="">
                                                </div>
                                                <div class="col-md-12 text-center mt-2">
                                                    <a href="#gallery"><button class="btn btn-primary">View All</button></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <h2 class="display-4 mb-1">Project Information</h2>
                                            <ul>
                                                <li class="mb-1">
                                                    <b>Applicant Name :</b> {{$project->applicant_name}}
                                                </li>
                                                <li class="mb-1">
                                                    <b>Applicant Email :</b> {{$project->email}}
                                                </li>
                                                <li class="mb-1">
                                                    <b>Applicant Phone :</b> {{$project->phone}}
                                                </li>
                                                <li class="mb-1">
                                                    <b>Property State :</b> {{$project->project_state}}
                                                </li>
                                                <li class="mb-1">
                                                    <b>Property Address :</b> {{$project->project_address}}
                                                </li>
                                                <li class="mb-1">
                                                    <b>Cross Collaterized :</b> {{$project->cross_collaterized ? 'Yes' : 'No'}}
                                                </li>
                                            </ul>
                                            <h2 class="display-4 mb-1">Current Fiancials</h2>
                                            <ul>
                                                <li class="mb-1">
                                                    <b>Current Value :</b> {{$project->current_property_value}}
                                                </li>
                                                <li class="mb-1">
                                                    <b>Current Debts :</b> {{$project->property_debt}}
                                                </li>
                                                <li class="mb-1">
                                                    <b>Anticipated Budget :</b> {{$project->anticipated_budget}}
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Team</h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                <li class="nav-item">
                                                  <a wire:ignore.self class="nav-link active" id="home-tab" data-toggle="tab" href="#home-owner" role="tab" aria-controls="home" aria-selected="true">Home Owner</a>
                                                </li>
                                                <li class="nav-item">
                                                  <a wire:ignore.self class="nav-link" id="profile-tab" data-toggle="tab" href="#builder" role="tab" aria-controls="profile" aria-selected="false">Builders</a>
                                                </li>
                                                <li class="nav-item">
                                                  <a wire:ignore.self class="nav-link" id="contact-tab" data-toggle="tab" href="#franchise" role="tab" aria-controls="contact" aria-selected="false">Franchises</a>
                                                </li>
                                                <li class="nav-item">
                                                  <a wire:ignore.self class="nav-link" id="contact1-tab" data-toggle="tab" href="#evaluator" role="tab" aria-controls="contact1" aria-selected="false">Evaluator</a>
                                                </li>
                                              </ul>
                                              <div class="tab-content" id="myTabContent">
                                                <div wire:ignore.self class="tab-pane fade show active" id="home-owner" role="tabpanel" aria-labelledby="home-tab">
                                                    <div class="row">
                                                        <div class="col-md-2">
                                                            <label for="">Select User</label>
                                                            <select wire:model='selectedUser' class="form-control">
                                                                <option value="">
                                                                    Select
                                                                </option>
                                                                @foreach ($user->homeOwners()->get() as $item)
                                                                    <option value="{{$item->id}}">
                                                                        {{$item->name}}
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label for="">Roles</label><br>
                                                            @foreach ($roles as $item)
                                                                <input wire:model="userRoles" type="checkbox" value="{{$item}}"> {{ucfirst(str_replace('_', ' ', $item))}}
                                                            @endforeach
                                                        </div>
                                                        <div class="col-md-6">
                                                            <button class="btn btn-primary" wire:click='addUser("home-owner")'>Add</button>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <table class="table mt-1">
                                                                <tr>
                                                                    <th>
                                                                        Name
                                                                    </th>
                                                                    <th>
                                                                        Email
                                                                    </th>
                                                                    <th>
                                                                        Roles
                                                                    </th>
                                                                    <th></th>
                                                                </tr>
                                                                @foreach ($this->homeOwners as $homeOwner)
                                                                <tr>
                                                                    <td>
                                                                        {{$homeOwner->user->name}}
                                                                    </td>
                                                                    <td>
                                                                        {{$homeOwner->user->email}}
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            @foreach ($homeOwner->roles as $key => $role)
                                                                            <li><b>{{$key}}: </b> {!!$role ? '<i class="bx bx-check-circle text-success"></i>' : '<i class="bx bx-x-circle text-danger"></i>'!!}</li>
                                                                            @endforeach
                                                                        </ul>
                                                                    </td>
                                                                    <td><button class="btn btn-danger" wire:click='deleteUser({{$homeOwner}})'>Delete</button></td>
                                                                </tr>
                                                                @endforeach
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div wire:ignore.self class="tab-pane fade" id="builder" role="tabpanel" aria-labelledby="profile-tab">
                                                    <div class="row">
                                                        <div class="col-md-2">
                                                            <label for="">Select User</label>
                                                            <select wire:model='selectedUser' class="form-control">
                                                                <option value="">
                                                                    Select
                                                                </option>
                                                                @foreach ($user->builders()->get() as $item)
                                                                    <option value="{{$item->id}}">
                                                                        {{$item->name}}
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label for="">Roles</label><br>
                                                            @foreach ($roles as $item)
                                                                <input wire:model="userRoles" type="checkbox" value="{{$item}}"> {{ucfirst(str_replace('_', ' ', $item))}}
                                                            @endforeach
                                                        </div>
                                                        <div class="col-md-6">
                                                            <button class="btn btn-primary" wire:click='addUser("builder")'>Add</button>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <table class="table mt-1">
                                                                <tr>
                                                                    <th>
                                                                        Name
                                                                    </th>
                                                                    <th>
                                                                        Email
                                                                    </th>
                                                                    <th>
                                                                        Roles
                                                                    </th>
                                                                    <th></th>
                                                                </tr>
                                                                @foreach ($this->builders as $builder)
                                                                <tr>
                                                                    <td>
                                                                        {{$builder->user->name}}
                                                                    </td>
                                                                    <td>
                                                                        {{$builder->user->email}}
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <ul>
                                                                                @foreach ($builder->roles as $key => $role)
                                                                                <li><b>{{$key}}: </b> {!!$role ? '<i class="bx bx-check-circle text-success"></i>' : '<i class="bx bx-x-circle text-danger"></i>'!!}</li>
                                                                                @endforeach
                                                                            </ul>
                                                                        </ul>
                                                                    </td>
                                                                    <td><button class="btn btn-danger" wire:click="deleteUser({{$builder}})">Delete</button></td>
                                                                </tr>
                                                                @endforeach
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div wire:ignore.self class="tab-pane fade" id="franchise" role="tabpanel" aria-labelledby="contact-tab">
                                                    <div class="row">
                                                        <div class="col-md-2">
                                                            <label for="">Select User</label>
                                                            <select wire:model='selectedUser' class="form-control">
                                                                <option value="">
                                                                    Select
                                                                </option>
                                                                @foreach ($user->franchises()->get() as $item)
                                                                    <option value="{{$item->id}}">
                                                                        {{$item->name}}
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label for="">Roles</label><br>
                                                            @foreach ($roles as $item)
                                                                <input wire:model="userRoles" type="checkbox" value="{{$item}}"> {{ucfirst(str_replace('_', ' ', $item))}}
                                                            @endforeach
                                                        </div>
                                                        <div class="col-md-6">
                                                            <button class="btn btn-primary" wire:click='addUser("franchise")'>Add</button>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <table class="table mt-1">
                                                                <tr>
                                                                    <th>
                                                                        Name
                                                                    </th>
                                                                    <th>
                                                                        Email
                                                                    </th>
                                                                    <th>
                                                                        Roles
                                                                    </th>
                                                                    <th></th>
                                                                </tr>
                                                                @foreach ($this->franchises as $franchise)
                                                                <tr>
                                                                    <td>
                                                                        {{$franchise->user->name}}
                                                                    </td>
                                                                    <td>
                                                                        {{$franchise->user->email}}
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <ul>
                                                                                @foreach ($franchise->roles as $key => $role)
                                                                                <li><b>{{$key}}: </b> {!!$role ? '<i class="bx bx-check-circle text-success"></i>' : '<i class="bx bx-x-circle text-danger"></i>'!!}</li>
                                                                                @endforeach
                                                                            </ul>
                                                                        </ul>
                                                                    </td>
                                                                    <td><button class="btn btn-danger" wire:click='deleteUser({{$franchise}})'>Delete</button></td>
                                                                </tr>
                                                                @endforeach
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div wire:ignore.self class="tab-pane fade" id="evaluator" role="tabpanel" aria-labelledby="contact-tab">
                                                    <div class="row">
                                                        <div class="col-md-2">
                                                            <label for="">Select User</label>
                                                            <select wire:model='selectedUser' class="form-control">
                                                                <option value="">
                                                                    Select
                                                                </option>
                                                                @foreach ($user->evaluators()->get() as $item)
                                                                    <option value="{{$item->id}}">
                                                                        {{$item->name}}
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label for="">Roles</label><br>
                                                            @foreach ($roles as $item)
                                                                <input wire:model="userRoles" type="checkbox" value="{{$item}}"> {{ucfirst(str_replace('_', ' ', $item))}}
                                                            @endforeach
                                                        </div>
                                                        <div class="col-md-6">
                                                            <button class="btn btn-primary" wire:click='addUser("evaluator")'>Add</button>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <table class="table mt-1">
                                                                <tr>
                                                                    <th>
                                                                        Name
                                                                    </th>
                                                                    <th>
                                                                        Email
                                                                    </th>
                                                                    <th>
                                                                        Roles
                                                                    </th>
                                                                    <th>
                                                                        
                                                                    </th>
                                                                </tr>
                                                                @foreach ($this->evaluators as $evaluator)
                                                                <tr>
                                                                    <td>
                                                                        {{$evaluator->user->name}}
                                                                    </td>
                                                                    <td>
                                                                        {{$evaluator->user->email}}
                                                                    </td>
                                                                    <td>
                                                                        <ul>
                                                                            <ul>
                                                                                @foreach ($evaluator->roles as $key => $role)
                                                                                <li><b>{{$key}}: </b> {!!$role ? '<i class="bx bx-check-circle text-success"></i>' : '<i class="bx bx-x-circle text-danger"></i>'!!}</li>
                                                                                @endforeach
                                                                            </ul>
                                                                        </ul>
                                                                    </td>
                                                                    <td><button class="btn btn-danger" wire:click='deleteUser({{$evaluator}})'>Delete</button></td>
                                                                </tr>
                                                                @endforeach
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                              </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Contracts</h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <a href="/contracts/create/{{$project->id}}"><button class="btn btn-primary">Create New Contract</button></a>
                                        </div>
                                        <div class="col-md-12">
                                            @livewire('tables.project-contract-table', ['params' => [
                                                'project_id' => $project->id
                                            ]])
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-12">
                        <div class="card" id="gallery">
                            <div class="card-header">
                                <h4 class="card-title">Project Gallery</h4>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h3 class="display-4">Photos</h3>
                                        </div>
                                        @foreach ((array)$project->photos as $item)
                                                @php
                                                $photo = $item;
                                                if($photo)
                                                    if(filter_var($photo, FILTER_VALIDATE_URL)){
                                                        $photo = explode("/", $photo);
                                                        $photo = $photo[count($photo) -2] . '/' . $photo[count($photo)-1];
                                                    }   
                                                @endphp
                                                    
                                            <div class="col-md-2">
                                                <img src="/stream/{{$photo}}" width="100%" alt="">
                                            </div>
                                        @endforeach
                                        <div class="col-md-12">
                                            <h3 class="display-4">Videos</h3>
                                        </div>
                                        @if ((array)$project->videos)
                                            @foreach ((array)$project->videos as $item)
                                                <div class="col-md-4">
                                                    <video src="{{$item['file']}}" width="100%" controls="true" autoplay="false">
                                                        <source src="{{$item['file']}}">
                                                    </video>
                                                </div>
                                            @endforeach
                                            
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>