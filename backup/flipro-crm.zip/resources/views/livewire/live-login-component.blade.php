<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
            <!-- login page start -->
            <section id="auth-login" class="row flexbox-container">
                <div class="col-11 col-md-6 col-lg-6 col-xl-4">
                    <div class="card disable-rounded-right mb-0 h-100 d-flex justify-content-center">
                        <div class="card-header" style="background-color: #165C98;">
                            <div class="card-content text-center align-self-center p-3">
                                <img class="img-fluid" src="/app-assets/images/pages/login.png"
                                alt="branding logo">
                            </div>
                        </div>
                        <div class="card-content mt-2">
                            <div class="card-body">
                                <div class="form-group mb-50">
                                    <label class="text-bold-600" for="exampleInputEmail1">Email address</label>
                                    <input wire:model='email' type="email" class="form-control"
                                        id="exampleInputEmail1" placeholder="Email address">
                                </div>
                                @error('email')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                                <div class="form-group">
                                    <label class="text-bold-600" for="exampleInputPassword1">Password</label>
                                    <input wire:model='password' type="password" class="form-control"
                                        id="exampleInputPassword1" placeholder="Password">
                                    @error('password')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div
                                    class="form-group d-flex flex-md-row flex-column justify-content-between align-items-center">
                                    <div class="text-right"><a href="auth-forgot-password.html"
                                    class="card-link"><small>Forgot Password?</small></a></div>
                                </div>
                                <button wire:target='login' wire:loading.attr="disabled" type="submit"
                                    wire:click='login' class="btn btn-primary glow w-100 position-relative">Login<i
                                    id="icon-arrow" class="bx bx-loader bx-spin" wire:loading
                                    wire:target='login'></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- login page ends -->
        </div>
    </div>
</div>
