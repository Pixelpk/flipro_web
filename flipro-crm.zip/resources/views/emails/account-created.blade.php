Hello {{$name}},
<p>
    Your account at Flipro has been created successfully.
</p>

<p>
    You can login to your account using the following details
</p>

<p>
    <b>Email:</b> {{$email}} <br>
    <b>Password:</b> {{$password}}
</p>


